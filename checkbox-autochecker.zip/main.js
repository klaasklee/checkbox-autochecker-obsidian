/*! Copyright (c) 2025 Klaas Klee
* Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

'use strict';

var obsidian = require('obsidian');

const DEFAULT_SETTINGS = {
    syncMode: "partial-strict",
    loggingEnabled: false
};
class CheckboxAutocheckerSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        containerEl.createEl("h2", { text: "Checkbox Autochecker Settings" });
        new obsidian.Setting(containerEl)
            .setName("Sync Mode")
            .setDesc("Control how parent checkboxes affect children when toggled.")
            .addDropdown((dropdown) => dropdown
            .addOption("loose", "Loose (no downward sync)")
            .addOption("partial-strict", "Partial Strict (only update unchecked children)")
            .addOption("strict", "Strict (overwrite all children)")
            .setValue(this.plugin.settings.syncMode)
            .onChange(async (value) => {
            this.plugin.settings.syncMode = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName("Enable Logging")
            .setDesc("Log debug information to console.")
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.loggingEnabled)
            .onChange(async (value) => {
            this.plugin.settings.loggingEnabled = value;
            await this.plugin.saveSettings();
        }));
    }
}

class CheckboxAutochecker extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.fileCache = new Map();
        this.filesBeingUpdated = new Set();
    }
    async onload() {
        console.log("CheckboxAutochecker plugin loaded");
        await this.loadSettings();
        this.addSettingTab(new CheckboxAutocheckerSettingTab(this.app, this));
        // init cache
        this.app.workspace.onLayoutReady(() => {
            const activeFile = this.app.workspace.getActiveFile();
            if (activeFile)
                this.cacheFileContent(activeFile);
        });
        // file-level vault sync - runs when file is modified
        this.registerEvent(this.app.vault.on("modify", async (file) => {
            if (!(file instanceof obsidian.TFile))
                return;
            // cache file first time
            if (!this.fileCache.has(file.path)) {
                await this.cacheFileContent(file);
            }
            const activeFile = this.app.workspace.getActiveFile();
            if (file.path === activeFile?.path) {
                await this.syncCurrentFile(file);
            }
        }));
        // editor-level real-time sync - runs while typing
        this.registerEvent(this.app.workspace.on("editor-change", (editor, view) => {
            this.handleEditorChange(editor);
        }));
    }
    async cacheFileContent(file) {
        const content = await this.app.vault.read(file);
        this.fileCache.set(file.path, content);
    }
    handleEditorChange(editor) {
        const content = editor.getValue();
        const syncedContent = syncCheckboxes(content, null, // no diff possible while typing
        this.settings.syncMode, this.settings.loggingEnabled);
        if (content !== syncedContent) {
            editor.setValue(syncedContent);
        }
    }
    // runs when file is saved/modified
    async syncCurrentFile(file) {
        // Prevent re-processing our own updates
        if (this.filesBeingUpdated.has(file.path)) {
            this.filesBeingUpdated.delete(file.path);
            return;
        }
        // only handle markdown files - no .canvas
        if (file.extension !== "md") {
            return;
        }
        const previousContent = this.fileCache.get(file.path) ?? "";
        const currentContent = await this.app.vault.read(file);
        if (previousContent === currentContent)
            return;
        // find which line was changed und run logic
        const changedLineIdx = this.detectChangedLine(previousContent, currentContent);
        const updatedContent = syncCheckboxes(currentContent, changedLineIdx, this.settings.syncMode, this.settings.loggingEnabled);
        // only write back if any changes occurred
        if (currentContent !== updatedContent) {
            this.filesBeingUpdated.add(file.path);
            await this.app.vault.modify(file, updatedContent);
            this.fileCache.set(file.path, updatedContent);
        }
        else {
            this.fileCache.set(file.path, currentContent);
        }
    }
    detectChangedLine(oldContent, newContent) {
        const oldLines = oldContent.split("\n");
        const newLines = newContent.split("\n");
        const maxLength = Math.max(oldLines.length, newLines.length);
        for (let i = 0; i < maxLength; i++) {
            if (oldLines[i] !== newLines[i]) {
                return i;
            }
        }
        return null;
    }
    // loads saved user settings
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    // saves updated user settings
    async saveSettings() {
        await this.saveData(this.settings);
    }
}
function syncCheckboxes(content, changedLineIdx, mode, logging) {
    if (logging)
        console.log("Sync triggered (mode:", mode, ")");
    const lines = content.split("\n");
    // parse lines into task objects
    const tasks = lines.map((line) => ({
        line,
        indent: line.search(/\S|$/),
        checked: /^\s*[-*] \[x\]/i.test(line),
        isTask: /^\s*[-*] \[[ x]\]/.test(line),
        children: [],
        parent: null,
    }));
    // build task tree - parent/child relationships based on indentation
    const stack = [];
    tasks.forEach((task, i) => {
        if (!task.isTask)
            return;
        while (stack.length && tasks[stack[stack.length - 1]].indent >= task.indent) {
            stack.pop();
        }
        if (stack.length) {
            const parentIdx = stack[stack.length - 1];
            task.parent = parentIdx;
            tasks[parentIdx].children.push(i);
        }
        stack.push(i);
    });
    // apply downward propagation if a checkbox was toggled
    if (changedLineIdx !== null && tasks[changedLineIdx]?.isTask) {
        const state = tasks[changedLineIdx].checked;
        const propagateDown = (index, state) => {
            tasks[index].checked = state;
            tasks[index].children.forEach((child) => {
                const childTask = tasks[child];
                if (mode === "strict") {
                    propagateDown(child, state);
                }
                else if (mode === "partial-strict") {
                    if (state === true && childTask.checked === false) {
                        propagateDown(child, state);
                    }
                    if (state === false) {
                        propagateDown(child, state);
                    }
                }
                // loose mode = no downward sync
            });
        };
        if (mode !== "loose") {
            propagateDown(changedLineIdx, state);
        }
    }
    // parent reflects childrens states - gets always applied
    const propagateUp = (idx) => {
        const parentIdx = tasks[idx].parent;
        if (parentIdx === null)
            return;
        const parentTask = tasks[parentIdx];
        const allChildrenChecked = parentTask.children.every((child) => tasks[child].checked);
        if (parentTask.checked !== allChildrenChecked) {
            parentTask.checked = allChildrenChecked;
            propagateUp(parentIdx);
        }
    };
    tasks.forEach((task, idx) => {
        if (task.isTask)
            propagateUp(idx);
    });
    // build return content for file
    return tasks
        .map((t) => t.isTask ? t.line.replace(/\[.\]/, t.checked ? "[x]" : "[ ]") : t.line)
        .join("\n");
}

module.exports = CheckboxAutochecker;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsic3JjL3NldHRpbmdzLnRzIiwic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwLCBQbHVnaW5TZXR0aW5nVGFiLCBTZXR0aW5nIH0gZnJvbSBcIm9ic2lkaWFuXCI7XG5cbmV4cG9ydCB0eXBlIFN5bmNNb2RlID0gXCJsb29zZVwiIHwgXCJwYXJ0aWFsLXN0cmljdFwiIHwgXCJzdHJpY3RcIjtcblxuZXhwb3J0IGludGVyZmFjZSBDaGVja2JveEF1dG9jaGVja2VyU2V0dGluZ3Mge1xuXHRzeW5jTW9kZTogU3luY01vZGU7XG5cdGxvZ2dpbmdFbmFibGVkOiBib29sZWFuO1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogQ2hlY2tib3hBdXRvY2hlY2tlclNldHRpbmdzID0ge1xuXHRzeW5jTW9kZTogXCJwYXJ0aWFsLXN0cmljdFwiLFxuXHRsb2dnaW5nRW5hYmxlZDogZmFsc2Vcbn07XG5cbmV4cG9ydCBjbGFzcyBDaGVja2JveEF1dG9jaGVja2VyU2V0dGluZ1RhYiBleHRlbmRzIFBsdWdpblNldHRpbmdUYWIge1xuXHRwbHVnaW46IGFueTtcblxuXHRjb25zdHJ1Y3RvcihhcHA6IEFwcCwgcGx1Z2luOiBhbnkpIHtcblx0XHRzdXBlcihhcHAsIHBsdWdpbik7XG5cdFx0dGhpcy5wbHVnaW4gPSBwbHVnaW47XG5cdH1cblxuXHRkaXNwbGF5KCk6IHZvaWQge1xuXHRcdGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG5cblx0XHRjb250YWluZXJFbC5lbXB0eSgpO1xuXHRcdGNvbnRhaW5lckVsLmNyZWF0ZUVsKFwiaDJcIiwgeyB0ZXh0OiBcIkNoZWNrYm94IEF1dG9jaGVja2VyIFNldHRpbmdzXCIgfSk7XG5cblx0XHRuZXcgU2V0dGluZyhjb250YWluZXJFbClcblx0XHRcdC5zZXROYW1lKFwiU3luYyBNb2RlXCIpXG5cdFx0XHQuc2V0RGVzYyhcIkNvbnRyb2wgaG93IHBhcmVudCBjaGVja2JveGVzIGFmZmVjdCBjaGlsZHJlbiB3aGVuIHRvZ2dsZWQuXCIpXG5cdFx0XHQuYWRkRHJvcGRvd24oKGRyb3Bkb3duKSA9PlxuXHRcdFx0XHRkcm9wZG93blxuXHRcdFx0XHRcdC5hZGRPcHRpb24oXCJsb29zZVwiLCBcIkxvb3NlIChubyBkb3dud2FyZCBzeW5jKVwiKVxuXHRcdFx0XHRcdC5hZGRPcHRpb24oXCJwYXJ0aWFsLXN0cmljdFwiLCBcIlBhcnRpYWwgU3RyaWN0IChvbmx5IHVwZGF0ZSB1bmNoZWNrZWQgY2hpbGRyZW4pXCIpXG5cdFx0XHRcdFx0LmFkZE9wdGlvbihcInN0cmljdFwiLCBcIlN0cmljdCAob3ZlcndyaXRlIGFsbCBjaGlsZHJlbilcIilcblx0XHRcdFx0XHQuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc3luY01vZGUpXG5cdFx0XHRcdFx0Lm9uQ2hhbmdlKGFzeW5jICh2YWx1ZTogc3RyaW5nKSA9PiB7XG5cdFx0XHRcdFx0ICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zeW5jTW9kZSA9IHZhbHVlIGFzIFN5bmNNb2RlO1xuXHRcdFx0XHRcdCAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG5cdFx0XHRcdFx0fSlcblx0XHRcdCk7XG5cblx0XHRuZXcgU2V0dGluZyhjb250YWluZXJFbClcblx0XHRcdC5zZXROYW1lKFwiRW5hYmxlIExvZ2dpbmdcIilcblx0XHRcdC5zZXREZXNjKFwiTG9nIGRlYnVnIGluZm9ybWF0aW9uIHRvIGNvbnNvbGUuXCIpXG5cdFx0XHQuYWRkVG9nZ2xlKCh0b2dnbGUpID0+XG5cdFx0XHRcdHRvZ2dsZVxuXHRcdFx0XHRcdC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5sb2dnaW5nRW5hYmxlZClcblx0XHRcdFx0XHQub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLnBsdWdpbi5zZXR0aW5ncy5sb2dnaW5nRW5hYmxlZCA9IHZhbHVlO1xuXHRcdFx0XHRcdFx0YXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG5cdFx0XHRcdFx0fSlcblx0XHRcdCk7XG5cdH1cbn1cbiIsImltcG9ydCB7IFBsdWdpbiwgVEZpbGUsIEVkaXRvciB9IGZyb20gXCJvYnNpZGlhblwiO1xuaW1wb3J0IHsgQ2hlY2tib3hBdXRvY2hlY2tlclNldHRpbmdUYWIsIERFRkFVTFRfU0VUVElOR1MsIENoZWNrYm94QXV0b2NoZWNrZXJTZXR0aW5ncywgU3luY01vZGUgfSBmcm9tIFwiLi9zZXR0aW5nc1wiO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDaGVja2JveEF1dG9jaGVja2VyIGV4dGVuZHMgUGx1Z2luIHtcblxuXHRwcml2YXRlIGZpbGVDYWNoZTogTWFwPHN0cmluZywgc3RyaW5nPiA9IG5ldyBNYXAoKTtcblx0cHJpdmF0ZSBmaWxlc0JlaW5nVXBkYXRlZDogU2V0PHN0cmluZz4gPSBuZXcgU2V0KCk7XG5cblx0c2V0dGluZ3MhOiBDaGVja2JveEF1dG9jaGVja2VyU2V0dGluZ3M7XG5cblx0YXN5bmMgb25sb2FkKCkge1xuXHRcdGNvbnNvbGUubG9nKFwiQ2hlY2tib3hBdXRvY2hlY2tlciBwbHVnaW4gbG9hZGVkXCIpO1xuXG5cdFx0YXdhaXQgdGhpcy5sb2FkU2V0dGluZ3MoKTtcblx0XHR0aGlzLmFkZFNldHRpbmdUYWIobmV3IENoZWNrYm94QXV0b2NoZWNrZXJTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG5cblx0XHQvLyBpbml0IGNhY2hlXG5cdFx0dGhpcy5hcHAud29ya3NwYWNlLm9uTGF5b3V0UmVhZHkoKCkgPT4ge1xuXHRcdFx0Y29uc3QgYWN0aXZlRmlsZSA9IHRoaXMuYXBwLndvcmtzcGFjZS5nZXRBY3RpdmVGaWxlKCk7XG5cdFx0XHRpZiAoYWN0aXZlRmlsZSkgdGhpcy5jYWNoZUZpbGVDb250ZW50KGFjdGl2ZUZpbGUpO1xuXHRcdH0pO1xuXG5cdFx0Ly8gZmlsZS1sZXZlbCB2YXVsdCBzeW5jIC0gcnVucyB3aGVuIGZpbGUgaXMgbW9kaWZpZWRcblx0XHR0aGlzLnJlZ2lzdGVyRXZlbnQoXG5cdFx0XHR0aGlzLmFwcC52YXVsdC5vbihcIm1vZGlmeVwiLCBhc3luYyAoZmlsZSkgPT4ge1xuXHRcdFx0XHRpZiAoIShmaWxlIGluc3RhbmNlb2YgVEZpbGUpKSByZXR1cm47XG5cblx0XHRcdFx0Ly8gY2FjaGUgZmlsZSBmaXJzdCB0aW1lXG5cdFx0XHRcdGlmICghdGhpcy5maWxlQ2FjaGUuaGFzKGZpbGUucGF0aCkpIHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLmNhY2hlRmlsZUNvbnRlbnQoZmlsZSk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCBhY3RpdmVGaWxlID0gdGhpcy5hcHAud29ya3NwYWNlLmdldEFjdGl2ZUZpbGUoKTtcblx0XHRcdFx0aWYgKGZpbGUucGF0aCA9PT0gYWN0aXZlRmlsZT8ucGF0aCkge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMuc3luY0N1cnJlbnRGaWxlKGZpbGUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KVxuXHRcdCk7XG5cblx0XHQvLyBlZGl0b3ItbGV2ZWwgcmVhbC10aW1lIHN5bmMgLSBydW5zIHdoaWxlIHR5cGluZ1xuXHRcdHRoaXMucmVnaXN0ZXJFdmVudChcblx0XHRcdHRoaXMuYXBwLndvcmtzcGFjZS5vbihcImVkaXRvci1jaGFuZ2VcIiwgKGVkaXRvciwgdmlldykgPT4ge1xuXHRcdFx0XHR0aGlzLmhhbmRsZUVkaXRvckNoYW5nZShlZGl0b3IpO1xuXHRcdFx0fSlcblx0XHQpO1xuXHR9XG5cblx0YXN5bmMgY2FjaGVGaWxlQ29udGVudChmaWxlOiBURmlsZSkge1xuXHRcdGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpO1xuXHRcdHRoaXMuZmlsZUNhY2hlLnNldChmaWxlLnBhdGgsIGNvbnRlbnQpO1xuXHR9XG5cblx0aGFuZGxlRWRpdG9yQ2hhbmdlKGVkaXRvcjogRWRpdG9yKSB7XG5cdFx0Y29uc3QgY29udGVudCA9IGVkaXRvci5nZXRWYWx1ZSgpO1xuXG5cdFx0Y29uc3Qgc3luY2VkQ29udGVudCA9IHN5bmNDaGVja2JveGVzKFxuXHRcdFx0Y29udGVudCxcblx0XHRcdG51bGwsIC8vIG5vIGRpZmYgcG9zc2libGUgd2hpbGUgdHlwaW5nXG5cdFx0XHR0aGlzLnNldHRpbmdzLnN5bmNNb2RlLFxuXHRcdFx0dGhpcy5zZXR0aW5ncy5sb2dnaW5nRW5hYmxlZFxuXHRcdCk7XG5cblx0XHRpZiAoY29udGVudCAhPT0gc3luY2VkQ29udGVudCkge1xuXHRcdFx0ZWRpdG9yLnNldFZhbHVlKHN5bmNlZENvbnRlbnQpO1xuXHRcdH1cblx0fVxuXG5cdC8vIHJ1bnMgd2hlbiBmaWxlIGlzIHNhdmVkL21vZGlmaWVkXG5cdGFzeW5jIHN5bmNDdXJyZW50RmlsZShmaWxlOiBURmlsZSkge1xuXHRcdC8vIFByZXZlbnQgcmUtcHJvY2Vzc2luZyBvdXIgb3duIHVwZGF0ZXNcblx0XHRpZiAodGhpcy5maWxlc0JlaW5nVXBkYXRlZC5oYXMoZmlsZS5wYXRoKSkge1xuXHRcdFx0dGhpcy5maWxlc0JlaW5nVXBkYXRlZC5kZWxldGUoZmlsZS5wYXRoKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHQvLyBvbmx5IGhhbmRsZSBtYXJrZG93biBmaWxlcyAtIG5vIC5jYW52YXNcblx0XHRpZiAoZmlsZS5leHRlbnNpb24gIT09IFwibWRcIikge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGNvbnN0IHByZXZpb3VzQ29udGVudCA9IHRoaXMuZmlsZUNhY2hlLmdldChmaWxlLnBhdGgpID8/IFwiXCI7XG5cdFx0Y29uc3QgY3VycmVudENvbnRlbnQgPSBhd2FpdCB0aGlzLmFwcC52YXVsdC5yZWFkKGZpbGUpO1xuXG5cdFx0aWYgKHByZXZpb3VzQ29udGVudCA9PT0gY3VycmVudENvbnRlbnQpIHJldHVybjtcblxuXHRcdC8vIGZpbmQgd2hpY2ggbGluZSB3YXMgY2hhbmdlZCB1bmQgcnVuIGxvZ2ljXG5cdFx0Y29uc3QgY2hhbmdlZExpbmVJZHggPSB0aGlzLmRldGVjdENoYW5nZWRMaW5lKHByZXZpb3VzQ29udGVudCwgY3VycmVudENvbnRlbnQpO1xuXHRcdGNvbnN0IHVwZGF0ZWRDb250ZW50ID0gc3luY0NoZWNrYm94ZXMoXG5cdFx0XHRjdXJyZW50Q29udGVudCxcblx0XHRcdGNoYW5nZWRMaW5lSWR4LFxuXHRcdFx0dGhpcy5zZXR0aW5ncy5zeW5jTW9kZSxcblx0XHRcdHRoaXMuc2V0dGluZ3MubG9nZ2luZ0VuYWJsZWRcblx0XHQpO1xuXG5cdFx0Ly8gb25seSB3cml0ZSBiYWNrIGlmIGFueSBjaGFuZ2VzIG9jY3VycmVkXG5cdFx0aWYgKGN1cnJlbnRDb250ZW50ICE9PSB1cGRhdGVkQ29udGVudCkge1xuXHRcdFx0dGhpcy5maWxlc0JlaW5nVXBkYXRlZC5hZGQoZmlsZS5wYXRoKTtcblx0XHRcdGF3YWl0IHRoaXMuYXBwLnZhdWx0Lm1vZGlmeShmaWxlLCB1cGRhdGVkQ29udGVudCk7XG5cdFx0XHR0aGlzLmZpbGVDYWNoZS5zZXQoZmlsZS5wYXRoLCB1cGRhdGVkQ29udGVudCk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMuZmlsZUNhY2hlLnNldChmaWxlLnBhdGgsIGN1cnJlbnRDb250ZW50KTtcblx0XHR9XG5cdH1cblxuXHRkZXRlY3RDaGFuZ2VkTGluZShvbGRDb250ZW50OiBzdHJpbmcsIG5ld0NvbnRlbnQ6IHN0cmluZyk6IG51bWJlciB8IG51bGwge1xuXHRcdGNvbnN0IG9sZExpbmVzID0gb2xkQ29udGVudC5zcGxpdChcIlxcblwiKTtcblx0XHRjb25zdCBuZXdMaW5lcyA9IG5ld0NvbnRlbnQuc3BsaXQoXCJcXG5cIik7XG5cdFx0Y29uc3QgbWF4TGVuZ3RoID0gTWF0aC5tYXgob2xkTGluZXMubGVuZ3RoLCBuZXdMaW5lcy5sZW5ndGgpO1xuXG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBtYXhMZW5ndGg7IGkrKykge1xuXHRcdFx0aWYgKG9sZExpbmVzW2ldICE9PSBuZXdMaW5lc1tpXSkge1xuXHRcdFx0XHRyZXR1cm4gaTtcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblxuXHQvLyBsb2FkcyBzYXZlZCB1c2VyIHNldHRpbmdzXG5cdGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcblx0XHR0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKTtcblx0fVxuXG5cdC8vIHNhdmVzIHVwZGF0ZWQgdXNlciBzZXR0aW5nc1xuXHRhc3luYyBzYXZlU2V0dGluZ3MoKSB7XG5cdFx0YXdhaXQgdGhpcy5zYXZlRGF0YSh0aGlzLnNldHRpbmdzKTtcblx0fVxufVxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBDT1JFIENIRUNLQk9YIExPR0lDXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmludGVyZmFjZSBUYXNrIHtcblx0bGluZTogc3RyaW5nO1xuXHRpbmRlbnQ6IG51bWJlcjtcblx0Y2hlY2tlZDogYm9vbGVhbjtcblx0aXNUYXNrOiBib29sZWFuO1xuXHRjaGlsZHJlbjogbnVtYmVyW107XG5cdHBhcmVudDogbnVtYmVyIHwgbnVsbDtcbn1cblxuZnVuY3Rpb24gc3luY0NoZWNrYm94ZXMoY29udGVudDogc3RyaW5nLCBjaGFuZ2VkTGluZUlkeDogbnVtYmVyIHwgbnVsbCwgbW9kZTogU3luY01vZGUsIGxvZ2dpbmc6IGJvb2xlYW4pOiBzdHJpbmcge1xuXHRpZiAobG9nZ2luZykgY29uc29sZS5sb2coXCJTeW5jIHRyaWdnZXJlZCAobW9kZTpcIiwgbW9kZSwgXCIpXCIpO1xuXG5cdGNvbnN0IGxpbmVzID0gY29udGVudC5zcGxpdChcIlxcblwiKTtcblxuXHQvLyBwYXJzZSBsaW5lcyBpbnRvIHRhc2sgb2JqZWN0c1xuXHRjb25zdCB0YXNrczogVGFza1tdID0gbGluZXMubWFwKChsaW5lKSA9PiAoe1xuXHRcdGxpbmUsXG5cdFx0aW5kZW50OiBsaW5lLnNlYXJjaCgvXFxTfCQvKSxcblx0XHRjaGVja2VkOiAvXlxccypbLSpdIFxcW3hcXF0vaS50ZXN0KGxpbmUpLFxuXHRcdGlzVGFzazogL15cXHMqWy0qXSBcXFtbIHhdXFxdLy50ZXN0KGxpbmUpLFxuXHRcdGNoaWxkcmVuOiBbXSxcblx0XHRwYXJlbnQ6IG51bGwsXG5cdH0pKTtcblxuXHQvLyBidWlsZCB0YXNrIHRyZWUgLSBwYXJlbnQvY2hpbGQgcmVsYXRpb25zaGlwcyBiYXNlZCBvbiBpbmRlbnRhdGlvblxuXHRjb25zdCBzdGFjazogbnVtYmVyW10gPSBbXTtcblx0dGFza3MuZm9yRWFjaCgodGFzaywgaSkgPT4ge1xuXHRcdGlmICghdGFzay5pc1Rhc2spIHJldHVybjtcblx0XHR3aGlsZSAoc3RhY2subGVuZ3RoICYmIHRhc2tzW3N0YWNrW3N0YWNrLmxlbmd0aCAtIDFdXS5pbmRlbnQgPj0gdGFzay5pbmRlbnQpIHtcblx0XHRcdHN0YWNrLnBvcCgpO1xuXHRcdH1cblx0XHRpZiAoc3RhY2subGVuZ3RoKSB7XG5cdFx0XHRjb25zdCBwYXJlbnRJZHggPSBzdGFja1tzdGFjay5sZW5ndGggLSAxXTtcblx0XHRcdHRhc2sucGFyZW50ID0gcGFyZW50SWR4O1xuXHRcdFx0dGFza3NbcGFyZW50SWR4XS5jaGlsZHJlbi5wdXNoKGkpO1xuXHRcdH1cblx0XHRzdGFjay5wdXNoKGkpO1xuXHR9KTtcblxuXHQvLyBhcHBseSBkb3dud2FyZCBwcm9wYWdhdGlvbiBpZiBhIGNoZWNrYm94IHdhcyB0b2dnbGVkXG5cdGlmIChjaGFuZ2VkTGluZUlkeCAhPT0gbnVsbCAmJiB0YXNrc1tjaGFuZ2VkTGluZUlkeF0/LmlzVGFzaykge1xuXHRcdGNvbnN0IHN0YXRlID0gdGFza3NbY2hhbmdlZExpbmVJZHhdLmNoZWNrZWQ7XG5cblx0XHRjb25zdCBwcm9wYWdhdGVEb3duID0gKGluZGV4OiBudW1iZXIsIHN0YXRlOiBib29sZWFuKSA9PiB7XG5cdFx0XHR0YXNrc1tpbmRleF0uY2hlY2tlZCA9IHN0YXRlO1xuXHRcdFx0dGFza3NbaW5kZXhdLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGNoaWxkVGFzayA9IHRhc2tzW2NoaWxkXTtcblxuXHRcdFx0XHRpZiAobW9kZSA9PT0gXCJzdHJpY3RcIikge1xuXHRcdFx0XHRcdHByb3BhZ2F0ZURvd24oY2hpbGQsIHN0YXRlKTtcblx0XHRcdFx0fSBlbHNlIGlmIChtb2RlID09PSBcInBhcnRpYWwtc3RyaWN0XCIpIHtcblx0XHRcdFx0XHRpZiAoc3RhdGUgPT09IHRydWUgJiYgY2hpbGRUYXNrLmNoZWNrZWQgPT09IGZhbHNlKSB7XG5cdFx0XHRcdFx0XHRwcm9wYWdhdGVEb3duKGNoaWxkLCBzdGF0ZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmIChzdGF0ZSA9PT0gZmFsc2UpIHtcblx0XHRcdFx0XHRcdHByb3BhZ2F0ZURvd24oY2hpbGQsIHN0YXRlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0Ly8gbG9vc2UgbW9kZSA9IG5vIGRvd253YXJkIHN5bmNcblx0XHRcdH0pO1xuXHRcdH07XG5cblx0XHRpZiAobW9kZSAhPT0gXCJsb29zZVwiKSB7XG5cdFx0XHRwcm9wYWdhdGVEb3duKGNoYW5nZWRMaW5lSWR4LCBzdGF0ZSk7XG5cdFx0fVxuXHR9XG5cblx0Ly8gcGFyZW50IHJlZmxlY3RzIGNoaWxkcmVucyBzdGF0ZXMgLSBnZXRzIGFsd2F5cyBhcHBsaWVkXG5cdGNvbnN0IHByb3BhZ2F0ZVVwID0gKGlkeDogbnVtYmVyKSA9PiB7XG5cdFx0Y29uc3QgcGFyZW50SWR4ID0gdGFza3NbaWR4XS5wYXJlbnQ7XG5cdFx0aWYgKHBhcmVudElkeCA9PT0gbnVsbCkgcmV0dXJuO1xuXHRcdGNvbnN0IHBhcmVudFRhc2sgPSB0YXNrc1twYXJlbnRJZHhdO1xuXHRcdGNvbnN0IGFsbENoaWxkcmVuQ2hlY2tlZCA9IHBhcmVudFRhc2suY2hpbGRyZW4uZXZlcnkoKGNoaWxkKSA9PiB0YXNrc1tjaGlsZF0uY2hlY2tlZCk7XG5cdFx0aWYgKHBhcmVudFRhc2suY2hlY2tlZCAhPT0gYWxsQ2hpbGRyZW5DaGVja2VkKSB7XG5cdFx0XHRwYXJlbnRUYXNrLmNoZWNrZWQgPSBhbGxDaGlsZHJlbkNoZWNrZWQ7XG5cdFx0XHRwcm9wYWdhdGVVcChwYXJlbnRJZHgpO1xuXHRcdH1cblx0fTtcblxuXHR0YXNrcy5mb3JFYWNoKCh0YXNrLCBpZHgpID0+IHtcblx0XHRpZiAodGFzay5pc1Rhc2spIHByb3BhZ2F0ZVVwKGlkeCk7XG5cdH0pO1xuXG5cdC8vIGJ1aWxkIHJldHVybiBjb250ZW50IGZvciBmaWxlXG5cdHJldHVybiB0YXNrc1xuXHRcdC5tYXAoKHQpID0+XG5cdFx0XHR0LmlzVGFzayA/IHQubGluZS5yZXBsYWNlKC9cXFsuXFxdLywgdC5jaGVja2VkID8gXCJbeF1cIiA6IFwiWyBdXCIpIDogdC5saW5lXG5cdFx0KVxuXHRcdC5qb2luKFwiXFxuXCIpO1xufVxuXG4iXSwibmFtZXMiOlsiUGx1Z2luU2V0dGluZ1RhYiIsIlNldHRpbmciLCJQbHVnaW4iLCJURmlsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBU08sTUFBTSxnQkFBZ0IsR0FBZ0M7QUFDNUQsSUFBQSxRQUFRLEVBQUUsZ0JBQWdCO0FBQzFCLElBQUEsY0FBYyxFQUFFLEtBQUs7Q0FDckIsQ0FBQztBQUVJLE1BQU8sNkJBQThCLFNBQVFBLHlCQUFnQixDQUFBO0lBR2xFLFdBQVksQ0FBQSxHQUFRLEVBQUUsTUFBVyxFQUFBO0FBQ2hDLFFBQUEsS0FBSyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUNuQixRQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0tBQ3JCO0lBRUQsT0FBTyxHQUFBO0FBQ04sUUFBQSxNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRTdCLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNwQixXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSwrQkFBK0IsRUFBRSxDQUFDLENBQUM7UUFFdEUsSUFBSUMsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDdEIsT0FBTyxDQUFDLFdBQVcsQ0FBQzthQUNwQixPQUFPLENBQUMsNkRBQTZELENBQUM7QUFDdEUsYUFBQSxXQUFXLENBQUMsQ0FBQyxRQUFRLEtBQ3JCLFFBQVE7QUFDTixhQUFBLFNBQVMsQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUM7QUFDOUMsYUFBQSxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsaURBQWlELENBQUM7QUFDOUUsYUFBQSxTQUFTLENBQUMsUUFBUSxFQUFFLGlDQUFpQyxDQUFDO2FBQ3RELFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUM7QUFDdkMsYUFBQSxRQUFRLENBQUMsT0FBTyxLQUFhLEtBQUk7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLEtBQWlCLENBQUM7QUFDbEQsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNILENBQUM7UUFFSCxJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUN0QixPQUFPLENBQUMsZ0JBQWdCLENBQUM7YUFDekIsT0FBTyxDQUFDLG1DQUFtQyxDQUFDO0FBQzVDLGFBQUEsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUNqQixNQUFNO2FBQ0osUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQztBQUM3QyxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtZQUN6QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0FBQzVDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2pDLENBQUMsQ0FDSCxDQUFDO0tBQ0g7QUFDRDs7QUNwRG9CLE1BQUEsbUJBQW9CLFNBQVFDLGVBQU0sQ0FBQTtBQUF2RCxJQUFBLFdBQUEsR0FBQTs7QUFFUyxRQUFBLElBQUEsQ0FBQSxTQUFTLEdBQXdCLElBQUksR0FBRyxFQUFFLENBQUM7QUFDM0MsUUFBQSxJQUFBLENBQUEsaUJBQWlCLEdBQWdCLElBQUksR0FBRyxFQUFFLENBQUM7S0F3SG5EO0FBcEhBLElBQUEsTUFBTSxNQUFNLEdBQUE7QUFDWCxRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQztBQUVqRCxRQUFBLE1BQU0sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQzFCLFFBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLDZCQUE2QixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzs7UUFHdEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLE1BQUs7WUFDckMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUM7QUFDdEQsWUFBQSxJQUFJLFVBQVU7QUFBRSxnQkFBQSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDbkQsU0FBQyxDQUFDLENBQUM7O0FBR0gsUUFBQSxJQUFJLENBQUMsYUFBYSxDQUNqQixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sSUFBSSxLQUFJO0FBQzFDLFlBQUEsSUFBSSxFQUFFLElBQUksWUFBWUMsY0FBSyxDQUFDO2dCQUFFLE9BQU87O0FBR3JDLFlBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNuQyxnQkFBQSxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNsQztZQUVELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3RELElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUUsSUFBSSxFQUFFO0FBQ25DLGdCQUFBLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNqQztTQUNELENBQUMsQ0FDRixDQUFDOztBQUdGLFFBQUEsSUFBSSxDQUFDLGFBQWEsQ0FDakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLGVBQWUsRUFBRSxDQUFDLE1BQU0sRUFBRSxJQUFJLEtBQUk7QUFDdkQsWUFBQSxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEMsQ0FBQyxDQUNGLENBQUM7S0FDRjtJQUVELE1BQU0sZ0JBQWdCLENBQUMsSUFBVyxFQUFBO0FBQ2pDLFFBQUEsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztLQUN2QztBQUVELElBQUEsa0JBQWtCLENBQUMsTUFBYyxFQUFBO0FBQ2hDLFFBQUEsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRWxDLE1BQU0sYUFBYSxHQUFHLGNBQWMsQ0FDbkMsT0FBTyxFQUNQLElBQUk7UUFDSixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQzVCLENBQUM7QUFFRixRQUFBLElBQUksT0FBTyxLQUFLLGFBQWEsRUFBRTtBQUM5QixZQUFBLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDL0I7S0FDRDs7SUFHRCxNQUFNLGVBQWUsQ0FBQyxJQUFXLEVBQUE7O1FBRWhDLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDMUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDekMsT0FBTztTQUNQOztBQUdELFFBQUEsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUksRUFBRTtZQUM1QixPQUFPO1NBQ1A7QUFFRCxRQUFBLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDNUQsUUFBQSxNQUFNLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV2RCxJQUFJLGVBQWUsS0FBSyxjQUFjO1lBQUUsT0FBTzs7UUFHL0MsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUMvRSxNQUFNLGNBQWMsR0FBRyxjQUFjLENBQ3BDLGNBQWMsRUFDZCxjQUFjLEVBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUM1QixDQUFDOztBQUdGLFFBQUEsSUFBSSxjQUFjLEtBQUssY0FBYyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLFlBQUEsTUFBTSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDOUM7YUFBTTtZQUNOLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDOUM7S0FDRDtJQUVELGlCQUFpQixDQUFDLFVBQWtCLEVBQUUsVUFBa0IsRUFBQTtRQUN2RCxNQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hDLE1BQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsUUFBQSxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBRTdELFFBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDaEMsZ0JBQUEsT0FBTyxDQUFDLENBQUM7YUFDVDtTQUNEO0FBQ0QsUUFBQSxPQUFPLElBQUksQ0FBQztLQUNaOztBQUdELElBQUEsTUFBTSxZQUFZLEdBQUE7QUFDakIsUUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7S0FDM0U7O0FBR0QsSUFBQSxNQUFNLFlBQVksR0FBQTtRQUNqQixNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBQ25DO0FBQ0QsQ0FBQTtBQWVELFNBQVMsY0FBYyxDQUFDLE9BQWUsRUFBRSxjQUE2QixFQUFFLElBQWMsRUFBRSxPQUFnQixFQUFBO0FBQ3ZHLElBQUEsSUFBSSxPQUFPO1FBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFFN0QsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzs7SUFHbEMsTUFBTSxLQUFLLEdBQVcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTTtRQUMxQyxJQUFJO0FBQ0osUUFBQSxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7QUFDM0IsUUFBQSxPQUFPLEVBQUUsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNyQyxRQUFBLE1BQU0sRUFBRSxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3RDLFFBQUEsUUFBUSxFQUFFLEVBQUU7QUFDWixRQUFBLE1BQU0sRUFBRSxJQUFJO0FBQ1osS0FBQSxDQUFDLENBQUMsQ0FBQzs7SUFHSixNQUFNLEtBQUssR0FBYSxFQUFFLENBQUM7SUFDM0IsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUk7UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQUUsT0FBTztRQUN6QixPQUFPLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDNUUsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ1o7QUFDRCxRQUFBLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTtZQUNqQixNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxQyxZQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1lBQ3hCLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2xDO0FBQ0QsUUFBQSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsS0FBQyxDQUFDLENBQUM7O0lBR0gsSUFBSSxjQUFjLEtBQUssSUFBSSxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRSxNQUFNLEVBQUU7UUFDN0QsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUU1QyxRQUFBLE1BQU0sYUFBYSxHQUFHLENBQUMsS0FBYSxFQUFFLEtBQWMsS0FBSTtBQUN2RCxZQUFBLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQzdCLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFJO0FBQ3ZDLGdCQUFBLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUUvQixnQkFBQSxJQUFJLElBQUksS0FBSyxRQUFRLEVBQUU7QUFDdEIsb0JBQUEsYUFBYSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztpQkFDNUI7QUFBTSxxQkFBQSxJQUFJLElBQUksS0FBSyxnQkFBZ0IsRUFBRTtvQkFDckMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFNBQVMsQ0FBQyxPQUFPLEtBQUssS0FBSyxFQUFFO0FBQ2xELHdCQUFBLGFBQWEsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQzVCO0FBQ0Qsb0JBQUEsSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFO0FBQ3BCLHdCQUFBLGFBQWEsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQzVCO2lCQUNEOztBQUVGLGFBQUMsQ0FBQyxDQUFDO0FBQ0osU0FBQyxDQUFDO0FBRUYsUUFBQSxJQUFJLElBQUksS0FBSyxPQUFPLEVBQUU7QUFDckIsWUFBQSxhQUFhLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ3JDO0tBQ0Q7O0FBR0QsSUFBQSxNQUFNLFdBQVcsR0FBRyxDQUFDLEdBQVcsS0FBSTtRQUNuQyxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3BDLElBQUksU0FBUyxLQUFLLElBQUk7WUFBRSxPQUFPO0FBQy9CLFFBQUEsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3BDLE1BQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RGLFFBQUEsSUFBSSxVQUFVLENBQUMsT0FBTyxLQUFLLGtCQUFrQixFQUFFO0FBQzlDLFlBQUEsVUFBVSxDQUFDLE9BQU8sR0FBRyxrQkFBa0IsQ0FBQztZQUN4QyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDdkI7QUFDRixLQUFDLENBQUM7SUFFRixLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsS0FBSTtRQUMzQixJQUFJLElBQUksQ0FBQyxNQUFNO1lBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25DLEtBQUMsQ0FBQyxDQUFDOztBQUdILElBQUEsT0FBTyxLQUFLO0FBQ1YsU0FBQSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQ04sQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FDdEU7U0FDQSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDZDs7OzsifQ==
